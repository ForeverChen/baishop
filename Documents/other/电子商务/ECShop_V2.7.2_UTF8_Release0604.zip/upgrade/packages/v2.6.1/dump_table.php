<?php

$temp = array('shop_config');

?>
