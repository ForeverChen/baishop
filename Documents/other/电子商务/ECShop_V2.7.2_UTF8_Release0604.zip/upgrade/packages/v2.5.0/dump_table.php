<?php

$temp = array('admin_action', 'article_cat', 'mail_templates', 'payment', 'article');

?>
