imgUrl1="data/afficheimg/20081027angsif.jpg";
imgtext1="ECShop";
imgLink1=escape("http://www.ecshop.com");
imgUrl2="data/afficheimg/20081027xuorxj.jpg";
imgtext2="maifou";
imgLink2=escape("http://www.maifou.net");
imgUrl3="data/afficheimg/20081027wdwd.jpg";
imgtext3="ECShop";
imgLink3=escape("http://www.wdwd.com");

var pics=imgUrl1+"|"+imgUrl2+"|"+imgUrl3;
var links=imgLink1+"|"+imgLink2+"|"+imgLink3;
var texts=imgtext1+"|"+imgtext2+"|"+imgtext3;