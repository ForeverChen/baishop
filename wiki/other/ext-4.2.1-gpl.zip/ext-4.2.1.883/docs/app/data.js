Docs = {
	"data": {
		"localStorageDb": "ext-4",
		"examples": [{
				"title": "系统管理",
				"items": [{
						"title": "系统用户管理",
						"name": "admin/SysAdmins.jspx",
						"url": "admin/SysAdmins.jspx",
						"icon": "",
						"description": "Showcase of Ext JS components using a preview release of the new Neptune theme"
					}, {
						"title": "角色权限管理",
						"name": "admin/SysRoles.jspx",
						"url": "admin/SysRoles.jspx",
						"icon": "",
						"description": "RSS feed reader example application that features a swappable reader panel layout."
					}, {
						"title": "应用模块管理",
						"name": "admin/SysModules.jspx",
						"url": "admin/SysModules.jspx",
						"icon": "",
						"description": "RSS feed reader example application that features a swappable reader panel layout."
					}, {
						"title": "组织架构管理",
						"name": "admin/SysDepts.jspx",
						"url": "admin/SysDepts.jspx",
						"icon": "",
						"description": "RSS feed reader example application that features a swappable reader panel layout."
					}
				]
			}, {
				"title": "数据管理",
				"items": [{
						"title": "系统枚举管理",
						"name": "dict/SysEnums.jspx",
						"url": "dict/SysEnums.jspx",
						"icon": "",
						"description": "Grid loaded from SOAP data"
					}, {
						"title": "系统参数管理",
						"name": "dict/SysParams.jspx",
						"url": "dict/SysParams.jspx",
						"icon": "",
						"description": "Grid loaded from binary AMF (Action Message Format) data"
					}
				]
			}
		],
		"classes": [],
		"search": [{
				"meta": {},
				"icon": "icon-class",
				"fullName": "Array",
				"sort": 1,
				"name": "Array",
				"url": "#!/api/Array"
			}, {
				"meta": {},
				"icon": "icon-method",
				"fullName": "Array.constructor",
				"sort": 3,
				"name": "constructor",
				"url": "#!/api/Array-method-constructor"
			}, {
				"meta": {},
				"icon": "icon-property",
				"fullName": "Array.length",
				"sort": 3,
				"name": "length",
				"url": "#!/api/Array-property-length"
			},
		],
		"signatures": [{
				"long": "abstract",
				"key": "abstract",
				"short": "ABS"
			}, {
				"long": "chainable",
				"key": "chainable",
				"short": "&gt;"
			}, {
				"long": "deprecated",
				"key": "deprecated",
				"short": "DEP"
			}, {
				"long": "&#9733;",
				"key": "new",
				"short": "&#9733;"
			}, {
				"long": "preventable",
				"key": "preventable",
				"short": "PREV"
			}, {
				"long": "private",
				"key": "private",
				"short": "PRI"
			}, {
				"long": "protected",
				"key": "protected",
				"short": "PRO"
			}, {
				"long": "readonly",
				"key": "readonly",
				"short": "R O"
			}, {
				"long": "removed",
				"key": "removed",
				"short": "REM"
			}, {
				"long": "required",
				"key": "required",
				"short": "REQ"
			}, {
				"long": "static",
				"key": "static",
				"short": "STA"
			}, {
				"long": "template",
				"key": "template",
				"short": "TMP"
			}
		],
		"commentsDomain": null,
		"showPrintButton": false,
		"source": true,
		"tests": false,
		"touchExamplesUi": false,
		"commentsUrl": null
	}
};